package BasePizzaPackage; //always ahve class and package name diff

public interface BasePizza {
    public int cost();
}
