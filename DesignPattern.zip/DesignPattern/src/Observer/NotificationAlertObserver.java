package Observer;

public interface NotificationAlertObserver {
    public void update();
}
