package WithStratergicDesignPattern.Stratergy;

public class SportsDriveStratergy implements DriveStratergy {

    @Override
    public void drive() {
        System.out.println("SportsDriveStratergy");
    }
}
