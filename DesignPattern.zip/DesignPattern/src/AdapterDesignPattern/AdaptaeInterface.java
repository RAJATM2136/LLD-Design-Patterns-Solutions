package AdapterDesignPattern;

public interface AdaptaeInterface {
    public int weightInKilo();
}
