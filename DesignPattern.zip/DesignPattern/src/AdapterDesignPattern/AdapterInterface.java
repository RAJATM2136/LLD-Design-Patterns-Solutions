package AdapterDesignPattern;

public interface AdapterInterface {
    public int weightInPounds();
}
