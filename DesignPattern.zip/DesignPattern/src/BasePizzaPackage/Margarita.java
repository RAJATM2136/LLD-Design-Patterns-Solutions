package BasePizzaPackage;

public class Margarita implements BasePizza{
    @Override
    public int cost() {
        return 120;
    }
}
