package IteratorDp;

public class Book {
    public int price;
    public String title;
    Book(int price, String title) {
        this.price = price;
        this.title = title;
    }
}
