package Toppings;

import BasePizzaPackage.BasePizza;

public interface ToppingsDecorator extends BasePizza {

}
