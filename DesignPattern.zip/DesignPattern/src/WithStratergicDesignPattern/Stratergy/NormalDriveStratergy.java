package WithStratergicDesignPattern.Stratergy;

public class NormalDriveStratergy implements DriveStratergy {
    @Override
    public void drive() {
        System.out.println("NormalDriveStratergy");
    }
}
