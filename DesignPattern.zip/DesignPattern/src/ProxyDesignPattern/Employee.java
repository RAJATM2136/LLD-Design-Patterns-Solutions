package ProxyDesignPattern;

public class Employee {
    public int EmployeeID;
}
