package IteratorDp;

public interface Aggregate {
    public BookIterator createIterator();
}
