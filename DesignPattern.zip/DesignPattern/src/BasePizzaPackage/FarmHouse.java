package BasePizzaPackage;

public class FarmHouse implements BasePizza{  //child class
    @Override
    public int cost() {
        return 100;
    }
}
