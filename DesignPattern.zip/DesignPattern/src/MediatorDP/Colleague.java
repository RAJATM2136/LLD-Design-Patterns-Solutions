package MediatorDP;

public interface Colleague {
    public void placeBid(int bidAmount);
    public void receiveNotification(int bidAmount);
}
