package WithStratergicDesignPattern.Stratergy;

public interface DriveStratergy {
    public void drive();
}
